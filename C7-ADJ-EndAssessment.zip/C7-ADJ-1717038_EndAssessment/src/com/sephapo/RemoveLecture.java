package com.sephapo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class RemoveLecture extends HttpServlet {
	private static final long serialVersionUID = 1L;

		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			Connection con;
			
			String lecture_id = request.getParameter("lecId");
			
			try {
				
				
				con = DatabaseConnection.initializeDatabase();
				
				
				
				String sql = "delete from lecture where lecture_id ='"+lecture_id+"'";
				
				PreparedStatement st1 = con.prepareStatement(sql);	
				
				//Execute the insert command using executeUpdate() to make changes in the database
				st1.executeUpdate();
				
				//Close all DB connections
				 st1.close(); 
				 con.close();
				 
				
				//Get the PrintWriter pointer/object to display the successful result message
				  PrintWriter out = response.getWriter();
				  out.println("<meta http-equiv='refresh' content='1; URL=AdminPanel.html'>");
				  out.println("<p style ='color:red;'> Lecture is Successfully Removed from the system! </p>");
				
				
				
			} catch (ClassNotFoundException e) {
				
				e.printStackTrace();
			} catch (SQLException e) {
				  PrintWriter out = response.getWriter();
				  out.println("<meta http-equiv='refresh' content='1; URL=AdminPanel.html'>");
				  out.println("<p style ='color:red;'> lecture  not Removed please try again! </p>");
			
				e.printStackTrace();
			}
			
			
		}




	
	}


