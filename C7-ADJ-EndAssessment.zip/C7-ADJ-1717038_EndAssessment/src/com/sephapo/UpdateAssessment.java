package com.sephapo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class UpdateAssessment extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	

		//Initialize the DB
		
				Connection con;
				String Assessment_id = request.getParameter("Assessment_id");
				try {
					
					
					 con = DatabaseConnection.initializeDatabase();
					
					
					
					String sql = "update Assessment set Assessment_type=? , score=?, Assessment_date=?, module_id=?, document=?, Duration=? where Assessment_id='"+Assessment_id+"'";
					
					PreparedStatement st = con.prepareStatement(sql);
					
					
					
					st.setString(1, (request.getParameter("Assessment_type")));
					st.setString(2, (request.getParameter("score")));
					st.setDate  (3,  Date.valueOf(request.getParameter("Assessment_date")));
					st.setString(4, (request.getParameter("module_id")));
					st.setString(5, (request.getParameter("document")));
					st.setString(6, (request.getParameter("Duration")));
					
	
					st.executeUpdate();
					
					//Close all DB connections
			
					
					//Get the PrintWriter pointer/object to display the successful result message
					PrintWriter out = response.getWriter();
					 out.println("<meta http-equiv='refresh' content='1; URL=SearchAssessmentUPDATE.html'>");
					 out.println("<p style ='color:black;'> Assessment is  Successfully Updated!! </p>");
					
					
				} catch (ClassNotFoundException e) {
					
					e.printStackTrace();
				} catch (SQLException e) {
					 PrintWriter out = response.getWriter();
					 out.println("<meta http-equiv='refresh' content='1; URL=SearchAssessmentUPDATE.html'>");
					 out.println("<p style ='color:black;'> Assessment is not Updated please try again </p>");
				
					e.printStackTrace();
				}
				
				
			}

	}


