package com.sephapo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class LectureRemoveAssessment extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	Connection con;
		
		String Assessment_id = request.getParameter("Assessment_id");
		
		try {
			
			
			con = DatabaseConnection.initializeDatabase();
			
			
			
			String sql = "delete from  Assessment where  Assessment_id ='"+ Assessment_id+"'";
			
			PreparedStatement st1 = con.prepareStatement(sql);	
			
			//Execute the insert command using executeUpdate() to make changes in the database
			st1.executeUpdate();
			
			//Close all DB connections
			 st1.close(); 
			 con.close();
			 
			
			//Get the PrintWriter pointer/object to display the successful result message
			 PrintWriter out = response.getWriter();
			 out.println("<html>");
			 out.println("<script language= 'javascript'>");
             out.println(" alert('Assessment is successfully removed!')");
             out.println(" </script>");
             out.println("<meta http-equiv='refresh' content='0; URL=LecturePanel.jsp'>");
             out.println("<meta name='keywords' content='automatic redirection'>");
             out.println("</html>");
			
			
			
			
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			PrintWriter out = response.getWriter();
			out.println("<html>");
			out.println("<script language= 'javascript'>");
            out.println(" alert('Assessment is not removed!')");
            out.println(" </script>");
            out.println("<meta http-equiv='refresh' content='0; URL=LecturePanel.jsp'>");
            out.println("<meta name='keywords' content='automatic redirection'>");
            out.println("</html>");
		
			e.printStackTrace();
		}
		
	}

}
