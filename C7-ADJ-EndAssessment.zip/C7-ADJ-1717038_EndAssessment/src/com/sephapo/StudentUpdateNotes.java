package com.sephapo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



public class StudentUpdateNotes extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Initialize the DB
		
		Connection con;
		String note_id = request.getParameter("note_id");
		try {
			
			
				 con = DatabaseConnection.initializeDatabase();
				
				
				
				String sql = "update notes set comments=? where note_id='"+note_id+"'";
				
				PreparedStatement st = con.prepareStatement(sql);
				
				
				
				st.setString(1, (request.getParameter("comment")));
			
				
	
				st.executeUpdate();
				
				//Close all DB connections
		
				
				
				//Get the PrintWriter pointer/object to display the successful result message
				PrintWriter out = response.getWriter();
				out.println("<html>");
				out.println("<script language= 'javascript'>");
	            out.println(" alert('Notes are successfully updated!')");
	            out.println(" </script>");
	            out.println("<meta http-equiv='refresh' content='0; URL=StudentPanel.jsp'>");
	            out.println("<meta name='keywords' content='automatic redirection'>");
	            out.println("</html>");
				
				
			
				
				
			} catch (ClassNotFoundException e) {
				
				e.printStackTrace();
			} catch (SQLException e) {
				 PrintWriter out = response.getWriter();
				 out.println("<html>");
				 out.println("<script language= 'javascript'>");
	             out.println(" alert('Student is successflly registered!')");
	             out.println(" </script>");
	             out.println("<meta http-equiv='refresh' content='0; URL=StudentPanel.jsp'>");
	             out.println("<meta name='keywords' content='automatic redirection'>");
	             out.println("</html>");
			
				e.printStackTrace();
		}
		
		
	}

}


