package com.sephapo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sephapo.DatabaseConnection;


public class RegisterStudent extends HttpServlet implements Servlet {
	private static final long serialVersionUID = 1L;

		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			
			//initialize database 
		
			Connection con;
			
			try {
			  
				
		      con = DatabaseConnection.initializeDatabase();
		      
		      String sql = "insert into student values (?,?,?,?,?)";
		      
		      
		      PreparedStatement st = con.prepareStatement(sql);
		     
				
				st.setString(1, (request.getParameter("id")));
				st.setString(2, (request.getParameter("name")));
			    st.setDate ( 3,  Date.valueOf(request.getParameter("DOB")));
			    st.setString(4, (request.getParameter("password")));
			    st.setString(5,	(request.getParameter("username")));
				
				
				st.executeUpdate();
				
				con.close();
				
				//Get the PrintWriter pointer/object to display the successful result message
				PrintWriter out = response.getWriter();
				out.println("<html>");
				out.println("<script language= 'javascript'>");
                out.println(" alert('Student is successflly registered!')");
                out.println(" </script>");
                out.println("<meta http-equiv='refresh' content='0; URL=AdminPanel.html'>");
                out.println("<meta name='keywords' content='automatic redirection'>");
                out.println("</html>");
			
		      
		      
			
			}catch (ClassNotFoundException e) {
				e.printStackTrace();
			}catch (SQLException e) {
				PrintWriter out = response.getWriter();
				out.println("<html>");
				out.println("<script language= 'javascript'>");
                out.println(" alert('Student is not registered!')");
                out.println(" </script>");
                out.println("<meta http-equiv='refresh' content='0; URL=AdminPanel.html'>");
                out.println("<meta name='keywords' content='automatic redirection'>");
                out.println("</html>");
				
				e.printStackTrace();
			}
	}
			

}
