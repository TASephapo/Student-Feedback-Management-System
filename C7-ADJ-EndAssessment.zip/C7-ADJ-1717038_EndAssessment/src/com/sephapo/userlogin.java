package com.sephapo;

import java.io.IOException;

import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.sephapo.DatabaseConnection;

public class userlogin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		Connection con;

		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String usertype = request.getParameter("usertype");

		if (usertype.equals("Admin")) {
			try {

				con = DatabaseConnection.initializeDatabase();

				PreparedStatement ps = con.prepareStatement("select username,password from Admin where username=? and password=?");
				ps.setString(1, username);
				ps.setString(2, password);
				

				ResultSet rs = ps.executeQuery();

				if (rs.next()) {
					
					  HttpSession session =request.getSession();
					  
					  
					  session.setAttribute("username", username);
					  session.setMaxInactiveInterval(30);
					  response.sendRedirect("AdminPanel.html");
					 

					
					return;
				}

				else {

					  out.println("<html>"); 
					  out.println("<script language= 'javascript'>");
					  out.println(" alert('Invalid credentials try again')");
					  out.println(" </script>");
					  out.println("<meta http-equiv='refresh' content='0; URL=HomePage.html'>");
					  out.println("<meta name='keywords' content='automatic redirection'>");
					  out.println("</html>");
				}

				return;
			} catch (ClassNotFoundException | SQLException e) {

				e.printStackTrace();
			}
		}

		else if (usertype.equals("Student")) {
			try {

				con = DatabaseConnection.initializeDatabase();

				PreparedStatement ps = con.prepareStatement("select username,password from student where username=? and password=? ");
				ps.setString(1, username);
				ps.setString(2, password);

				ResultSet rs = ps.executeQuery();

				if (rs.next()) {
					
					HttpSession session =request.getSession();
					session.setAttribute("username", username);
					session.setMaxInactiveInterval(30);
					response.sendRedirect("StudentPanel.jsp");
					 
					return;
				}

				else {

					  out.println("<html>"); out.println("<script language= 'javascript'>");
					  out.println(" alert('Invalid credentials try again')");
					  out.println(" </script>");
					  out.println("<meta http-equiv='refresh' content='0; URL=UserLogin.jsp'>");
					  out.println("<meta name='keywords' content='automatic redirection'>");
					  out.println("</html>");

				}

				return;
			} catch (ClassNotFoundException | SQLException e) {

				e.printStackTrace();
			}
		}

		else if (usertype.equals("Lecture")) {
			try {

				con = DatabaseConnection.initializeDatabase();

				PreparedStatement ps = con.prepareStatement("select username,password from lecture where username=? and password=? ");
				ps.setString(1, username);
				ps.setString(2, password);

				ResultSet rs = ps.executeQuery();

				if (rs.next()) {
					
					 HttpSession session =request.getSession();
					  
					  
					  session.setAttribute("username", username);
					  session.setMaxInactiveInterval(120);
					  response.sendRedirect("LecturePanel.jsp");
					 
					return;
				}

				else {
					  out.println("<html>"); out.println("<script language= 'javascript'>");
					  out.println(" alert('Invalid credentials try again')");
					  out.println(" </script>");
					  out.println("<meta http-equiv='refresh' content='0; URL=UserLogin.jsp'>");
					  out.println("<meta name='keywords' content='automatic redirection'>");
					  out.println("</html>");

				}

				return;
			} catch (ClassNotFoundException | SQLException e) {

				e.printStackTrace();
			}
		} else {
			  out.println("<html>"); out.println("<script language= 'javascript'>");
			  out.println(" alert('Invalid credentials try again')");
			  out.println(" </script>");
			  out.println("<meta http-equiv='refresh' content='0; URL=UserLogin.jsp'>");
			  out.println("<meta name='keywords' content='automatic redirection'>");
			  out.println("</html>");
		}

	}

}
