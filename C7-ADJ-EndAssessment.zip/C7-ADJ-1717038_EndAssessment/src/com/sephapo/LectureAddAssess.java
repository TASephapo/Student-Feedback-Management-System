package com.sephapo;

public class LectureAddAssess {
	
	 //local variables
	  
	   
	   String  Assessment_id,Assessment_type , marks,  Assdate, module_id ,document, time1; 

	   
	   //set functions
	    public void setAssessment_id(String Assessment_id) {
	        this.Assessment_id = Assessment_id;
	    }
	    
	    public void setAssessment_type(String Assessment_type) {
	        this.Assessment_type = Assessment_type;
	    }

	   
	    public void setmarks(String marks) {
	        this.marks = marks;
	    }
	    
	    public void setAssdate(String Assdate) {
	        this.Assdate = Assdate;
	    }
	    
	    public void setmodule_id(String module_id) {
	        this.module_id = module_id;
	    }
	    
	    public void setdocument(String document) {
	        this.document = document;
	    }
	    
	    public void settime1(String time1) {
	        this.time1 = time1;
	    }


        //get functions

	   
	    public String getAssessment_id() {
	        return Assessment_id;
	    }
	    public String getAssessment_type() {
	        return Assessment_type ;
	    }
	    
	    public String  getmarks() {
	        return  marks;
	    }
	    
	    public String getAssdate() {
	        return Assdate;
	    }
	    public String getmodule_id() {
	        return module_id;
	    }
	    
	    public String getdocument() {
	        return document;
	    }
	    
	    public String gettime1() {
	        return time1;
	    }


}
