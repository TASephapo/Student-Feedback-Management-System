package com.sephapo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class UpddateStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//Initialize the DB
		
				Connection con;
				String student_id = request.getParameter("id");
				try {
					
					
					 con = DatabaseConnection.initializeDatabase();
					
					
					
					String sql = "update student set student_name=?, DOB=?, password=?, Username=? where student_id='"+student_id+"'";
					
					PreparedStatement st = con.prepareStatement(sql);
					
					
					
					st.setString(1, (request.getParameter("name")));
					st.setDate ( 2,  Date.valueOf(request.getParameter("DOB")));
					st.setString(3, (request.getParameter("password")));
					st.setString(4, (request.getParameter("Username")));

					

					st.executeUpdate();
					
					//Close all DB connections
			
					
					//Get the PrintWriter pointer/object to display the successful result message
					PrintWriter out = response.getWriter();
					out.println("<html>");
					out.println("<script language= 'javascript'>");
	                out.println(" alert('Student is successflly Updated!')");
	                out.println(" </script>");
	                out.println("<meta http-equiv='refresh' content='0; URL=AdminPanel.html'>");
	                out.println("<meta name='keywords' content='automatic redirection'>");
	                out.println("</html>");
				
				
					
					
				} catch (ClassNotFoundException e) {
					
					e.printStackTrace();
				} catch (SQLException e) {
					 PrintWriter out = response.getWriter();
					 out.println("<html>");
					 out.println("<script language= 'javascript'>");
		             out.println(" alert('There is an error please try again!)");
		             out.println(" </script>");
		             out.println("<meta http-equiv='refresh' content='0; URL=AdminPanel.html'>");
		             out.println("<meta name='keywords' content='automatic redirection'>");
		             out.println("</html>");
					
					e.printStackTrace();
				}
				

		
	}

}
