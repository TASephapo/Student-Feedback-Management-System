package com.sephapo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class UpdateCourse extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		
	    Connection con;
		
	   String Course_id = request.getParameter("course_id");
		
		try {
			
			
			con = DatabaseConnection.initializeDatabase();
			
			
			
		
			 

			String sql = "update Course set Course_name=?  where Course_id ='"+Course_id+"'";
			
			PreparedStatement st3 = con.prepareStatement(sql);	
			st3.setString(1, (request.getParameter("Course_name")));
			
			//Execute the insert command using executeUpdate() to make changes in the database
			st3.executeUpdate();
			
			//Close all DB connections
			 st3.close(); 
			 con.close();
			 
			
			//Get the PrintWriter pointer/object to display the successful result message
			  PrintWriter out = response.getWriter();
			  out.println("<meta http-equiv='refresh' content='1; URL=AdminPanel.html'>");
			  out.println("<p style ='color:black;'> Course is Successfully Updated!! </p>");
			
			
			
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			  PrintWriter out = response.getWriter();
			  out.println("<meta http-equiv='refresh' content='1; URL=AdminPanel.html'>");
			  out.println("<p style ='color:red;'> Records not Updated!! </p>");
		
			e.printStackTrace();
		}
		
	}

}
