package com.sephapo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class AddFeedBack extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//initialize connection DB
		
				Connection con;
				
				
				try {
					 
					
					con = DatabaseConnection.initializeDatabase();
					
					String sql ="insert into feedback values (?,?,?,?,?,?)";
					

					PreparedStatement st = con.prepareStatement(sql);
					st.setString(1, (request.getParameter("lecId")));
					st.setString(2, (request.getParameter("id")));
					st.setString(3, (request.getParameter("grade")));
					st.setString(4, (request.getParameter("Assessment_id")));
					st.setString(5, (request.getParameter("module_id")));
					st.setString(6, (request.getParameter("comment")));
					
					st.executeUpdate();
					
					st.close();
					PrintWriter out = response.getWriter();
			
					
					 out.println("<html>");
					 out.println("<script language= 'javascript'>");
                     out.println(" alert('Feedback is successfully added')");
                     out.println(" </script>");
                     out.println("<meta http-equiv='refresh' content='0; URL=LecturePanel.jsp'>");
                     out.println("<meta name='keywords' content='automatic redirection'>");
                     out.println("</html>");
                     
				}catch (ClassNotFoundException e) {
					e.printStackTrace();
				}catch (SQLException e) {
					PrintWriter out = response.getWriter();
					out.println("<html>");
					 out.println("<script language= 'javascript'>");
                    out.println(" alert('Feedback is not added please try again')");
                    out.println(" </script>");
                    out.println("<meta http-equiv='refresh' content='0; URL=LecturePanel.jsp'>");
                    out.println("<meta name='keywords' content='automatic redirection'>");
                    out.println("</html>");					
                    e.printStackTrace();
				}
				
	}

}
