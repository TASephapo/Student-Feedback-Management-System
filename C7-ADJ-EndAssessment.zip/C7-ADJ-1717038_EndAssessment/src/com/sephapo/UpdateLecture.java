package com.sephapo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class UpdateLecture extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Initialize the DB
		
		Connection con;
		String lecture_id = request.getParameter("lecId");
		try {
			
			
			 con = DatabaseConnection.initializeDatabase();
			
			
			
			String sql = "update lecture set lecture_name=?, password=? where lecture_id='"+lecture_id+"'";
			
			PreparedStatement st = con.prepareStatement(sql);
			
			
			
			st.setString(1, (request.getParameter("name")));
			st.setString(2, (request.getParameter("password")));
			

			st.executeUpdate();
			
			//Close all DB connections
	
			
			//Get the PrintWriter pointer/object to display the successful result message
			PrintWriter out = response.getWriter();
			 out.println("<meta http-equiv='refresh' content='1; URL=SearchModuleUpdate.html'>");
			 out.println("<p style ='color:black;'> Lecture is  Successfully Updated!! </p>");
			
			
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			 PrintWriter out = response.getWriter();
			 out.println("<meta http-equiv='refresh' content='1; URL=SearchModuleUpdate.html'>");
			 out.println("<p style ='color:black;'> Lecture is not Updated please try again </p>");
		
			e.printStackTrace();
		}
		
		
	}

}
