package com.sephapo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sephapo.DatabaseConnection;


public class RemoveModule extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		
		Connection con;
		
		String Module_id = request.getParameter("Module_id");
		//String Course_id = request.getParameter("Course_id");
		try {
			
			
			con = DatabaseConnection.initializeDatabase();
			
			
			/*
			 * String query
			 * ="delete Course_id from course where Course_id ='"+Course_id+"'";
			 * PreparedStatement st = con.prepareStatement(query); st.executeUpdate();
			 */

			String sql = "delete from module where Module_id ='"+Module_id+"'";
			
			PreparedStatement st1 = con.prepareStatement(sql);	
			
			//Execute the insert command using executeUpdate() to make changes in the database
			st1.executeUpdate();
			
			//Close all DB connections
			 st1.close(); 
			 con.close();
			 
			
			//Get the PrintWriter pointer/object to display the successful result message
			  PrintWriter out = response.getWriter();
			  out.println("<meta http-equiv='refresh' content='1; URL=AdminPanel.html'>");
			  out.println("<p style ='color:red;'> Records Successfully Removed!! </p>");
			
			
			
		} catch (ClassNotFoundException e) {
			
			e.printStackTrace();
		} catch (SQLException e) {
			  PrintWriter out = response.getWriter();
			  out.println("<meta http-equiv='refresh' content='1; URL=AdminPanel.html'>");
			  out.println("<p style ='color:red;'> Records not Removed!! </p>");
		
			e.printStackTrace();
		}
		
		
	}



	}


