package com.sephapo;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Assignment extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	  //initialize connection DB
		
		Connection con;
		
		
		try {
			
			con = DatabaseConnection.initializeDatabase();
			
			String sql ="insert into Assessment values (?,?,?,?,?,?,?)";
			

			PreparedStatement st = con.prepareStatement(sql);
			st.setString(1, (request.getParameter("Assessment_id")));
			st.setString(2, (request.getParameter("Assessment_type")));
			st.setString(3, (request.getParameter("marks")));
			st.setDate  (4,  Date.valueOf(request.getParameter("Assdate")));
			st.setString(5, (request.getParameter("module_id")));
			st.setString(6 ,(request.getParameter("document")));
			st.setString(7, (request.getParameter("time1")));
			
			st.executeUpdate();
			
			st.close();
			
			PrintWriter out = response.getWriter();
			out.println("<html>");
			out.println("<script language= 'javascript'>");
            out.println(" alert('Assignment is successfully assigned!')");
            out.println(" </script>");
            out.println("<meta http-equiv='refresh' content='0; URL=AdminPanel.html'>");
            out.println("<meta name='keywords' content='automatic redirection'>");
            out.println("</html>");
			
		
		}catch (ClassNotFoundException e) {
			e.printStackTrace();
		}catch (SQLException e) {
			PrintWriter out = response.getWriter();
			out.println("<html>");
			out.println("<script language= 'javascript'>");
            out.println(" alert(' error!please try again !')");
            out.println(" </script>");
            out.println("<meta http-equiv='refresh' content='0; URL=Assessment.jsp'>");
            out.println("<meta name='keywords' content='automatic redirection'>");
            out.println("</html>");
			
			e.printStackTrace();
		}
		
		}
	
	}


